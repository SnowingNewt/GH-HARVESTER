# Minhas Dorks Personalizadas. 
# Todos Os Creditos Para mim ;)
# GH

import argparse
from os import system, name
import os
import sys
def clear():
    return os.system('cls' if os.name == 'nt' else 'clear')

print ("")
A = """
 ██████╗ ██╗  ██╗      ██╗  ██╗ █████╗ ██████╗ ██╗   ██╗███████╗███████╗████████╗███████╗██████╗
██╔════╝ ██║  ██║      ██║  ██║██╔══██╗██╔══██╗██║   ██║██╔════╝██╔════╝╚══██╔══╝██╔════╝██╔══██╗
██║  ███╗███████║█████╗███████║███████║██████╔╝██║   ██║█████╗  ███████╗   ██║   █████╗  ██████╔╝
██║   ██║██╔══██║╚════╝██╔══██║██╔══██║██╔══██╗╚██╗ ██╔╝██╔══╝  ╚════██║   ██║   ██╔══╝  ██╔══██╗
╚██████╔╝██║  ██║      ██║  ██║██║  ██║██║  ██║ ╚████╔╝ ███████╗███████║   ██║   ███████╗██║  ██║
 ╚═════╝ ╚═╝  ╚═╝      ╚═╝  ╚═╝╚═╝  ╚═╝╚═╝  ╚═╝  ╚═══╝  ╚══════╝╚══════╝   ╚═╝   ╚══════╝╚═╝  ╚═╝
            
               ...
             ;::::;
           ;::::; :;
         ;:::::'   :;
        ;:::::;     ;.
       ,:::::'       ;           OOO
       ::::::;       ;          OOOOO
       ;:::::;       ;         OOOOOOOO
      ,;::::::;     ;'         / OOOOOOO
    ;:::::::::`. ,,,;.        /  / DOOOOOO
  .';:::::::::::::::::;,     /  /     DOOOO
 ,::::::;::::::;;;;::::;,   /  /        DOOO
;`::::::`'::::::;;;::::: ,#/  /          DOOO
:`:::::::`;::::::;;::: ;::#  /            DOOO
::`:::::::`;:::::::: ;::::# /              DOO
`:`:::::::`;:::::: ;::::::#/               DOO
 :::`:::::::`;; ;:::::::::##                OO
 ::::`:::::::`;::::::::;:::#                OO
 `:::::`::::::::::::;'`:;::#                O
  `:::::`::::::::;' /  / `:#
   ::::::`:::::;'  /  /   `#
============================================================================================ 
 	Este software é Rolling Release e foi criado por: David A. Mascaro 
*Use os Exploits/Dorks para roubar: 
Dados,Documentos Confidenciais,Certidões,Senhas,CPF,RG,Data de Nascimento,Nome da Mãe e afins junto as Dorks! 
BOA DIVERSÃO! ;)

|YouTube: https://www.youtube.com/channel/UCSFHAjOqExiP5PXFLitmcdA | *Me Siga também no Instagram: https://www.instagram.com/pentestjr |
    """

print ("")
print(A)

parser = argparse.ArgumentParser("GH-HARVERSTER.py , formatter_class=argparse.RawTextHelpFormatter")
parser.add_argument ("-g", "--google", help ="Google-Mode", action= 'store_true')

args = parser.parse_args()

if args.google :
 clear()
 from Modes import Gmode


print ('*PARA USAR AS DORKS AQUI MESMO ACRESCENTE O COMANDO "-g"')

print ('==================|>CONTEM CPF, RG E SENHA DO GOVERNO!<|==============================')

print ('intext: "cpf + conta" | inurl: "gov.br"')
print ('filetype: xml "conta + cpf" | inurl: "gov.br"')
print ('intitle: "index of" | inurl: "uploads" [Esta dork pode conter alguns DLs ja hackeados]')
print ('intitle: *index of | inurl: "wp-content AND uploads"')
print ('intitle: "index of" | inurl: "wp-content + password"')
print ('intitle:"Index of" passwd')
print ('intext: "senha.conta.agencia,cpf,rg" | governo"')
print ('intext: "senha,conta.RG.CPF.cartão.numero.2022" | "pastebin"')
print ('intext: "CPF + RG + CONTA"')
print ('filetype: pdf "CPF + RG + NOME DA MAE"')
print ('filetype: pdf "CPF" + "RG" + "NOME DA MAE"')
print ('site:pastebin.com intext:admin.password')
print ('intext: leaks | intitle: "password" | site: "pastebin"')
print ('filetype:mdb -site:gov -site:milexported email addressesext:(doc | pdf | xls | txt | ps | rtf | odt | sxw | psw | ppt | pps | xml) (intext:confidential salary | intext:”budget approved”)')
print ('inurl:confidential')
print ('ext:asp inurl:pathto.asp')
print ('ext:ccm ccm -catacomb')
print ('intext: "leaks" | intitle: "password" | site: "pastebin" | filetype: "txt"')
print ('filetype:bak inurl:"htaccesslpasswdlshadowlhtusers"')
print ('filetype:bak "password"')
print ('filetype:bak "RG + CPF"')
print ('filetype: bak "user" + "pass"')
print ('intext: "senha.conta.agencia,cpf,rg" | "governo"')
print ('intext: "senha,conta.RG.CPF.cartão.numero.2022" | "pastebin"')
print ('intitle:"index of" intext:CPF+RG')
print ('intitle:"index of intext:CPF+RG+SENHA"')

# Estas são para diversão!
print ('==================|>ESTAS SÃO PARA CAMERAS DE SEGURANÇA<|=============================')
print ('intitle:"WEBCAM 7 " inurl:/admin.html')
print ('intitle:"WEBCAM 7 " site:.com')
print ('intitle: "webcam XP 5"')
print ('intitle: "webcam XP 7"')
print ('inurl:currenttime inurl:top.htm')
print ('inurl:/view.shtml')
print ('inurl:"lvappl.htm"')
print ('inurl: CgiStart?page=')
print ('inurl:/view.shtml')
print ('intitle: "Live View/ — AXIS”')
print ('inurl:iview/view.shtml')
print ('inurl:ViewerFrame?M0de=')
print ('inurl:ViewerFrame?M0de=Refresh')
print ('inurl:axis-cgi/jpg')
print ('inurl:"ViewerFrame?Mode=" -viewerframe-mode.com/')

# Para Uso Geral
print ('==================|>PARA USO GERAL<|=============================')
print ('intitle: "index of" spwd.db.passwd-pam.conf')
print ('intitle:"index of" + "admin" | filetype: "sql"')
print ('intitle: "index of" | inurl: "cat.php?=1"')
print ('inurl: /wp-content/uploads/ inurl:"robots.txt" "Disallow:" filetype:txt')
print ('intitle: "index of" spwd.db.passwd-pam.conf')
print ('intitle:"index of" + "admin" | filetype: "sql"')
print ('intitle: "index of" | inurl: "cat.php?=1"')
print ('inurl: /wp-content/uploads/ inurl:"robots.txt" "Disallow:" filetype:txt')
print ('intitle: Index of wp-admin')
print ('filetype:log "See" "ipsec copyright"')
print ('inurl: "calenda" rscri pt users.txt"')
print ('inurl: ccbill | filetype: "logdata"')
print ('inurl:cgi-bin inurl:calendar.cfg')
print ('inurl: passl ist.txt')
print ('intitle:"index of" "htpasswd" "htgroup"  intitle:"dist" pache htpasswd.c')
print ('inurl:adminpanel site:gov.*')
print ('inurl:admin filetype:xlsx site:gov.*')
print ('intitle:"index of" "wp-config.php.bak"')
print ('site:gov.* intitle:"index of" *.csv')
print ('Fwd: intitle: "atvise - next generation"')
print ('intitle:index od settings.py')
print ('inurl:*admin | login" | inurl:php |.asp')
print ('site:pastebin.com intitle: "cpanel"')
print ('inurl:admin fieltpe:xls')
print ('site:papaly.com + keyword')
print ('inurl:admin filetype:xls')
print ('inurl:admin filetype:txt')
print ('inurl:admin filetype:txt')
print ('intitle:"MODBUS TCP RS485 Converter" intext:"Module Name: MMTCPBCONV" "powered by Atmel ARM."')
print ('intitle:"Yawcam" inurl:8081')
print ('inurl:/web-console/ServerInfo.jsp | inurl:/status?full=true')
print ('inurl:/intranet/login.php')
print ('intitle:"index of" site:gov.in [Busque por arquivos Indexados provavelmente com erro Dl!]')


